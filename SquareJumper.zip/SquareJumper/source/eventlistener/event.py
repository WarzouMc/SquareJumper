class Event:

    def __init__(self):
        print('test')